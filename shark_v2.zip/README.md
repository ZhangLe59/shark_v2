# shark_v2
Command to generate required pkg: 
pip freeze > requirements.txt
